from random import *
class ennemi:
    def __init__(self):
        self.nom = choice(['Gobelin', 'Slime', 'Patate Hanté'])
        self.vie = randint(80, 130)
        self.attaque = randint(5, 20)
        self.defense = randint(0, 7)
        self.arme = [None, None, 0]

    def stats(self):
            '''pour voir ses stats et inventaire'''
            print("nom =", self.nom)
            print("vie =", self.vie)
            print("attaque =", self.attaque)
            print("defense =", self.defense)


    def voir_vie(self):
        return self.vie


    def prit_degat(self, prit):
        self.vie -= prit


    def nom(self):
        return self.nom()


    def defense(self):
        return self.defense

ennemi = ennemi()

##ennemi.stats()