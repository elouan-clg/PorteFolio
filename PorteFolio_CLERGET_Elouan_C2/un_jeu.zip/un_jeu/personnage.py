class Perso:
    """"""
    def __init__(self, nom):
        """le Perso."""
        self.nom = nom


    def dps(self):
        self.vie = 100
        self.argent = 0
        self.attaque = 25
        self.defense = 5
        # nom, description, stats
        self.arme = [None, None, 0]
        self.bouclier = [None, None, 0]
        self.armure = [None, None, 0]


    def tank(self):
        self.vie = 150
        self.argent = 0
        self.attaque = 15
        self.defense = 10
        self.arme = [None, None, 0]
        self.bouclier = [None, None, 0]
        self.armure = [None, None, 0]


    def stats(self):
        '''pour voir ses stats et inventaire'''
        print("nom =", self.nom)
        print("vie =", self.vie)
        print("argent =", self.argent)
        print("attaque =", self.attaque)
        print("defense =", self.defense)
        print("arme =", self.arme)
        print("bouclier =", self.bouclier)
        print("armure =", self.armure)


    def voir_vie(self):
        return self.vie


    def prit_degat(self, prit):
        self.vie = self.vie - prit


    def defense(self):
        return self.defense + self.armure[2] + self.bouclier[2]

