from random import *
def espace():
    for i in range(16):
        print('')

def action():
    rep = ''
    while rep not in ['attaque', 'defendre']:
        rep = input('se défendre ou attaquer ( il faut écrire <<defendre>> ou <<attaque>>')
    return rep

def attaque(a, b, modif):
    deg = a.attaque + a.arme[2] -b.defense - modif + randint(-2, 2)
    if deg < 0:
        deg = 0
    return deg

def ptetrecrit(x):
    resu = randint(0, 10)
    if resu == 10:
        x = 2 * x
        print("COUP CRITIQUE")
    return resu


