from personnage import *
from ennemi import *
from cache_bouzou import *
le_nom = input('quel est le nom de votre personnage?')
joueur = Perso(le_nom)
classe = ''
while classe not in ['tank', 'dps']:
    classe = input('dps ou tank?')
    if classe == 'dps':
        joueur.dps()
    elif classe == 'tank':
        joueur.tank()
##joueur.dps()
joueur.stats()
espace()
ennemi.stats()
espace()

def combat():
    modife = modifj = 0
    dmg_sur_ennemi = 0
    dmg_sur_joueur = 0
    while joueur.vie > 0 and ennemi.vie > 0:
        espace()
        print('il vous reste', joueur.voir_vie(), 'PV')
        print('il reste',ennemi.voir_vie(),' PV à', ennemi.nom)
    ##    joueur.stats()
    ##    ennemi.stats()
        motifj = 0
sa        rep = action()
        if rep == 'attaque':
            dmg_sur_ennemi = attaque(joueur, ennemi, modife)
            dmg_sur_ennemi = ptetrecrit(dmg_sur_ennemi)
            print("vous lui infligez", dmg_sur_ennemi, 'dégats')
            ennemi.prit_degat(dmg_sur_ennemi)
        elif rep == 'defendre':
            modifj = joueur.defense
        if ennemi.vie > 0:
            modife = 0
            act_adv = randint(0, 3)
            if act_adv == 0:
                print(ennemi.nom,'se défend')
                modife = ennemi.defense
            else:
                print(ennemi.nom,'attaque')
                dmg_sur_joueur = attaque(ennemi, joueur, modifj)
                dmg_sur_joueur = ptetrecrit(dmg_sur_joueur)
                print("il vous inflige", dmg_sur_joueur, 'dégats')
                joueur.prit_degat(dmg_sur_joueur)

combat()